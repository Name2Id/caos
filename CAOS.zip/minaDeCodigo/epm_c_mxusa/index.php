<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Landing Page</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="./public/CrectanguloscuadradosSS/crcss.css">
    </head>
    <body>
        <header>
            <h1 class="header">WELCOME TO THE MAIN DOOR</h1>
        </header>

        <section class="container">
            <h2 class="header">seccion 1</h2>
            <div class="content">
                <h2 class="titles">Area</h2>
                <p class="parrafos">Publica</p>
                <a href="./public/">Entrar</a>
            </div>
        </section>

        <section class="container">
            <h2 class="header">seccion 2</h2>
            <div class="content">
                <h2 class="titles">Area</h2>
                <p class="parrafos">Privada</p>
                <a href="./private/">Entrar</a>
            </div>
        </section>

        <footer>
            <h3 class="header">&copy; epm c rg.</h3>
        </footer>
    </body>
</html>