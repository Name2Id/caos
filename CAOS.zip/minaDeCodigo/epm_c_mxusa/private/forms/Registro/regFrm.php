<?php

function frmReg ($user,$password) {

}

function viewFrmReg ($action,$method,int $inputs) {

}