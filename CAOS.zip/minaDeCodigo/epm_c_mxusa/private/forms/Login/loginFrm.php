<?php

function frmLgn ($user,$password) {

}

function viewFrmLgn ($action,$method,int $inputs) {

}