<?php

    function c () {
        return "cerebro";
    }

?>