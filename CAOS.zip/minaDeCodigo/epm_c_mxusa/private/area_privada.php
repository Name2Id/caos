<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Area Privada</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../public/CrectanguloscuadradosSS/crcss.css">
    </head>
    <body>
        <header>
            <h1 class="header">clonando codigo php,html,css y js</h1>
        </header>

        <section class="container">
            <h2 class="header">me quedo con lo mejor de cada repo.</h2>
            <div class="content">
                <h2 class="titles">Actividad de clonar la materia prima.</h2>
                <p class="parrafos">
                    iremos visitando y clonando 
                    todos y cada uno de los repositorios 
                    de cuentas pasadas de github propias.
                </p>
            </div>
            <div class="content">
                <h2 class="titles">Con que finalidad.</h2>
                <p class="parrafos">
                    analisaremos cada fragmento 
                    de codigo y tomaremos y refactorizaremos
                    el codigo, proceso que redactare en las
                    siguientes secciones.
                </p>
            </div>
        </section>

        <section class="container">
            <h2 class="header">Primero lo primero.</h2>
            <div class="content">
                <h2 class="titles">Identificar las urls.</h2>
                <p class="parrafos">
                    para poder clonar los repos 
                    necesitamos las urls de los repos.
                </p>
            </div>
            <div class="content">
                <h2 class="titles">Categorizados por usuario.</h2>
                <p class="parrafos">
                    a continuacion te mostrare la 
                    lista de usuarios github que 
                    tengo creados para que puedas 
                    visitar todos los perfiles 
                    y clonar todos los proyectos. 
                </p>
            </div>
        </section>
    </body>
</html>