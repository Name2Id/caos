<?php
/**
 * Este es una funcion en desarrollo
 * todavia es muy prematura para 
 * utilizarla con distintas bases
 * de datos . pero funciona 
 * perfectamente en automatico
 * si esta utilizando xampp
 * como servidor local.
 */
function conn () {
    $server = "localhost";
    $user = "root";
    $password = "";
    $database = "test";
    $port = "3306";
    $conn = new mysqli ($server,$user,$password,$database,$port);
    if ($conn->connect_errno) {
        return "error.";
    } else {
        return $conn; 
    }
}