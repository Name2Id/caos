<?php

/**
 * para que este metodo funcione
 * los campos de la base de datos
 * los nombres de los inputs y
 * las keys del arreglo $campos deben
 * coincidir osea deben de ser iguales.
 */
function guarda ($submit,$table,$campos,$conn) {
    if ( isset($_POST[$submit]) ) {
        $nombres = [];
        $fields = '';
        $valores = '';
        for ($i = 0; $i < count($campos); $i++) {
            $nombres[$campos[$i]] = $_POST[$campos[$i]];
            $fields .= $campos[$i].',';
        }
        $fields = substr($fields,0,-1);
        foreach ($nombres as $key => $value) {
            $valores .= "'".$value."',";
        }
        $valores = substr($valores,0,-1);
        $query = "INSERT INTO $table ($fields) VALUES ($valores)";
        if (mysqli_query($conn,$query)) {
            return "success.";
        }else{
            return "fail.";
        }
    }
}