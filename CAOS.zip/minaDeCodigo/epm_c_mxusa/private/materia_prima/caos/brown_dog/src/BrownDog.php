<?php
    class BrownDog {
        
    }
?>