<?php

require_once ('./Etappi6Selector.php');

pick ('Estappi7');