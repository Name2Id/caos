<?php


function pick ($version = 'Estappi6') {
    switch ($version) {
        case 'Estappi7': require_once ('./Estappi7/CodigObjetoYEjecutable/Estappi7.php'); break;
        default : require_once ('./Estappi6/Estappi6.php');
    }
}