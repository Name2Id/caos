<?php

class Estappi6_Pagina {
    private array $html;
    public function __construct ($text,$program,array $addOnIt = null,array $addUnderIt = null) {
        $this->html = [
            "parte_1" => '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge"><title>',
            "enlazamiento_1" => $text['title_of_the_head'],
            "parte_2" => '</title><meta name="description" content="Rgg.">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="'.$text['css_1_path'].
            '"></head><body>',
            $addOnIt,
            $program,
            $addUnderIt,
            "end" => '</body></html>'
        ];
    }
    public function cloneP () {
        return $this->html;
    }
}