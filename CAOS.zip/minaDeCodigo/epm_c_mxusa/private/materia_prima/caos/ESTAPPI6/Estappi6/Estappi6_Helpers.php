<?php

function section (string $helper) {
    $end = "</section>";
    return "<section class='bp fco' id='Estappi6'>".$helper.$end;
}
function div (string $helper) {
    $end = "</div>";
    return "<div class='bp dvm'>".$helper.$end;
}
function h2 (string $helper) {
    $end = "</h2>";
    return "<h2>".$helper.$end;
}
function h3 (string $helper) {
    $end = "</h3>";
    return "<h3>".$helper.$end;
}
function h5 (string $helper) {
    $end = "</h5>";
    return "<h5>".$helper.$end;
}
function p (string $helper) {
    $end = "</p>";
    return "<p>".$helper.$end;
}
function a (string $helper,string $url = '#') {
    $end = "</a>";
    return "<a href='".$url."'>".$helper.$end;
}
function conn () {
    $server = "localhost";
    $user = "root";
    $password = "";
    $database = "test";
    $port = "3306";
    $conn = new mysqli ($server,$user,$password,$database,$port);
    if ($conn->connect_errno) {
        return "error.";
    } else {
        return $conn; 
    }
}
/**
 * para que este metodo funcione
 * los campos de la base de datos
 * los nombres de los inputs y
 * las keys del arreglo $campos deben
 * coincidir ose deben de ser iguales.
 */
function guarda ($submit,$table,$campos,$conn) {
    if ( isset($_POST[$submit]) ) {
        $nombres = [];
        $fields = '';
        $valores = '';
        for ($i = 0; $i < count($campos); $i++) {
            $nombres[$campos[$i]] = $_POST[$campos[$i]];
            $fields .= $campos[$i].',';
        }
        $fields = substr($fields,0,-1);
        foreach ($nombres as $key => $value) {
            $valores .= "'".$value."',";
        }
        $valores = substr($valores,0,-1);
        $query = "INSERT INTO $table ($fields) VALUES ($valores)";
        if (mysqli_query($conn,$query)) {
            return "success.";
        }else{
            return "fail.";
        }
    } else {
        #GET
        return "Hola Bienvenido.";
    }
}