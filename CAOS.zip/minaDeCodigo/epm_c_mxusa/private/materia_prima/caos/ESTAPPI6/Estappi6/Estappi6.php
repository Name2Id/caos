<?php //Siga los siguientes pasos Para ejecutar Estappi6

// Paso 1 | clonamos la informacion base. (Bloque base)

require_once './Estappi6/Estappi6_Texto.php';

$estappi6Texto = new Estappi6_Texto;

######################Area De Personalizacion###############

$estappi6Texto->cssPath('./Estappi6/Estappi6_Css.css');
$estappi6Texto->tabTitle('Estappi6');

############################################################

$DatosModificados = $estappi6Texto->cloneT();

// Paso 2 | Introducimos el bloque base al programa Seccion y clonamos la Seccion.

require_once './Estappi6/Estappi6_Seccion.php';

$estappi6Seccion = new Estappi6_Seccion ($DatosModificados);

$SeccionClonada = $estappi6Seccion->cloneS();

// Paso 3 | enviamos el bloque base y la seccion a la Pagina ademas clonamos la pagina.

require_once './Estappi6/Estappi6_Pagina.php';

######################Area De Personalizacion###############

require_once './Estappi6/Estappi6_Helpers.php';

############################################################

$estappi6Pagina = new Estappi6_Pagina ($DatosModificados,$SeccionClonada,
/**Agrega aqui mas secciones por encima de la seccion clonada 
 * ejemplo :
*/
[
    section(
        div(
            h3('Agregar un amigo').p('GitHub User.').
            "
            <form action='./' method='POST'>
                <input type='text' placeholder='email' name='email'>
                <input type='text' placeholder='user' name='usergithub'>
                <input type='text' placeholder='url' name='urlgithub'>
                <input type='submit' name='save' value='guardar'>
            </form>
            "
        ).
        div(
            h2('Resultado de la primer ejecucion de Estappi6').p(guarda(
                'save',
                'friends',
                [
                    'email',
                    'usergithub',
                    'urlgithub'
                ],
                conn()
            )).
            h5(a('enlace'))
        )
    )
]
,
/**Agrega aqui mas secciones por debajo de la seccion clonada
 * ejemplo:
 */
[
    section(
        div(
            h3('seccion por debajo').p('lado izquierdo')
        ).
        div(
            h2('titulo h2').p('lado derecho').
            h5(a('enlace'))
        )
    )
]
);

$paginaClonada = $estappi6Pagina->cloneP();

// Paso 4 | enviamos la pagina clonada y Unificamos los tres 
# bloques anteriores para obtener el resultado.

require_once './Estappi6/Estappi6_Juntar.php';

$estappi6Juntar = new Estappi6_Juntar;

echo $estappi6Juntar->esto ($paginaClonada);