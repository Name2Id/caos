<?php

class Estappi6_Texto {
    private array $text = [
        "title_of_the_head" => "Estapp!",#getter implemented
        "h3_title" => "About Me",
        "p_1_text" => "obsecionado con PHP.
        y la tecnologia en general.",
        "h2_title" => "support via MAZA $ APP to deploy this website",
        "p_2_text" => "\$ramiro.garcia_gonzalez
        This app(maza) its not a sponsore.
        of this website.",
        "h5_title" => "Download",
        "class_1" => " bp",
        "class_2" => " fco",
        "class_3" => " dvm",
        "id_1" => "Estappi6",
        "css_1_path" => "./bones.css",#getter implemented
        "url" => "https://www.google.com/search?q=withmaza&sxsrf=APwXEdf7sbeKKmO1ddZd6grlItpfe9X7nQ%3A1684781282219&ei=4rhrZO-JDarR0PEP-JKgeA&ved=0ahUKEwjvgueuy4n_AhWqKDQIHXgJCA8Q4dUDCBE&uact=5&oq=withmaza&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQAzIFCAAQgAQ6CAgAEIAEELADOgoIABCABBCwAxAKOggIABCKBRCRAjoHCAAQigUQQzoLCAAQgAQQsQMQgwE6EQguEIAEELEDEIMBEMcBENEDOgsILhCABBCxAxCDAToLCAAQigUQsQMQgwE6CAguEIAEELEDOggIABCABBCxAzoFCC4QgAQ6BwgAEIAEEAo6DQguEIAEELEDENQCEAo6BwguEIAEEAo6DQguENQCELEDEIAEEAo6CgguEIAEELEDEApKBAhBGAFQwAtYzyZgxihoBHAAeACAAYkBiAHPB5IBAzIuN5gBAKABAcgBCsABAQ&sclient=gws-wiz-serp"
    ];
    public function cloneT () {
        return $this->text;
    }
    public function cssPath (string $path) {
        $this->text['css_1_path'] = $path;
    }
    public function tabTitle (string $title) {
        $this->text['title_of_the_head'] = $title;
    }
}