<?php

class Estappi6_Tiempo {
    private array $time = [
        "pago_por_hora" => 0,
        "hora_de_entrada" => '',
        "hora_de_salida" => '',
        "fecha" => ''
    ];
}