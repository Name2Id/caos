<?php

class Estappi7_Juntar {

    private function recursivo ($array) {
        $seguirJuntando = '';
        foreach ($array as $key => $value) {
            $seguirJuntando .= $value;
        }
        return $seguirJuntando;
    }
    public function esto ($html) {
        $Juntar = '';
        foreach ($html as $key => $value) {
            if (is_array($value)) {
                $Juntar .= $this->recursivo($value);
            } else {
                $Juntar .= $value;
            }
        }
        return $Juntar;
    }
}