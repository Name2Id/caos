<?php

class Estappi7_Seccion {
    private array $program;
    public function __construct (
        $text
    ) {
        $this->program = [
            "THIS" => '<section class="'.$text['class_1'].
            $text['class_2'].
            '" id="'.$text['id_1'].'"><div class="'.
            $text['class_1'].
            $text['class_3'].'"><h3>',
            "enlazamiento_2" => $text['h3_title'],
            "parte_3" => '</h3><p>',
            "enlazamiento_3" => $text['p_1_text'],
            "parte_4" => '</p></div><div class="'.$text['class_1'].
            $text['class_3'].'"><h2>',
            "enlazamiento_4" => $text['h2_title'],
            "parte_5" => '</h2><p>',
            "enlazamiento_5" => $text['p_2_text'],
            "parte_6" => '</p><h5><a href="'.$text['url'].'">',
            "enlazamiento_6" => $text['h5_title'],
            "TOTHIS" => '</a></h5></div></section>'
        ];
    }
    public function cloneS () {
        return $this->program;
    }
}