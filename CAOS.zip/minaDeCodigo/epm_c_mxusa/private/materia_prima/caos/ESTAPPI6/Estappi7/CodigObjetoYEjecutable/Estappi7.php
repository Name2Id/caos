<?php //Siga los siguientes pasos Para ejecutar Estappi7

// Paso 1 | clonamos la informacion base. (Bloque base)

require_once './Estappi7/CodigoFuente/Estappi7_Texto.php';

$estappi7Texto = new Estappi7_Texto;

######################Area De Personalizacion###############0

$estappi7Texto->cssPath('./Estappi7/CodigoFuente/Estappi7_Css.css');
$estappi7Texto->tabTitle('Estappi7');

############################################################0

$DatosModificados = $estappi7Texto->cloneT();

// Paso 2 | Introducimos el bloque base al programa Seccion y clonamos la Seccion.

require_once './Estappi7/CodigoFuente/Estappi7_Seccion.php';

$estappi7Seccion = new Estappi7_Seccion ($DatosModificados);

$SeccionClonada = $estappi7Seccion->cloneS();

// Paso 3 | enviamos el bloque base y la seccion a la Pagina ademas clonamos la pagina.

require_once './Estappi7/CodigoFuente/Estappi7_Pagina.php';

######################Area De Personalizacion###############1

require_once './Estappi7/CodigoFuente/Estappi7_Helpers.php';

############################################################1

$estappi7Pagina = new Estappi7_Pagina ($DatosModificados,$SeccionClonada,
/**Agrega aqui mas secciones por encima de la seccion clonada 
 * ejemplo :
*/
[
    section(
        div(
            h3('Agregar un amigo').p('GitHub User.').
            "
            <form action='./' method='POST'>
                <input type='text' placeholder='email' name='email'>
                <input type='text' placeholder='user' name='usergithub'>
                <input type='text' placeholder='url' name='urlgithub'>
                <input type='submit' name='save' value='guardar'>
            </form>
            "
        ).
        div(
            h2('Resultado de la primer ejecucion de Estappi7').p(guarda(
                'save',
                'friends',
                [
                    'email',
                    'usergithub',
                    'urlgithub'
                ],
                conn()
            )).
            h5(a('enlace'))
        )
    )
]
,
/**Agrega aqui mas secciones por debajo de la seccion clonada
 * ejemplo:
 */
[
    section(
        div(
            h3('seccion por debajo').p('lado izquierdo')
        ).
        div(
            h2('titulo h2').p('lado derecho').
            h5(a('enlace'))
        )
    )
]
);

$paginaClonada = $estappi7Pagina->cloneP();

// Paso 4 | enviamos la pagina clonada y Unificamos los tres 
# bloques anteriores para obtener el resultado.

require_once './Estappi7/CodigoFuente/Estappi7_Juntar.php';

$estappi7Juntar = new Estappi7_Juntar;

echo $estappi7Juntar->esto ($paginaClonada);