<?php

    function WhateverTFYWtCI($default = "whatever the fuck you want to call it.") {
        return $default;
    }

?>