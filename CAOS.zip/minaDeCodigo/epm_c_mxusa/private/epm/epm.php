<?php
    /**
     * Esta funcion tendra que 
     * ser precedida de la funcion 
     * echo para poder visualizar 
     * el string original por pantalla.
     */
    function epm () :string {
        return "essencial para m&iacute;";
    }

?>