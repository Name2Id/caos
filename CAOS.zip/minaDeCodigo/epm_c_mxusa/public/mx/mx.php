<?php
/**
 * Same as epm ();
 */
    function mx () {
        return "M&eacute;xico";
    }
?>