<?php
    function usa () {
        return "United States of America";
    }
    //wrapper
    /**
     * en caso que se necesite
     * definir una ruta especifica,
     * global o relativa.
     */
    function dfnRuta ($ruta) {
        set_include_path($ruta);
    }
    function gtRuta () {
        return get_include_path();
    }
?>